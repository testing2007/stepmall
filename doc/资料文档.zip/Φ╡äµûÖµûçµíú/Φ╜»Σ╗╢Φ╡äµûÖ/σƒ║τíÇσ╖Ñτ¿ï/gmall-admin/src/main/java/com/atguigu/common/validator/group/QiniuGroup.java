/**
 * Copyright (c) 2016-2019 谷粒开源 All rights reserved.
 *
 * https://www.guli.cloud
 *
 * 版权所有，侵权必究！
 */

package com.atguigu.common.validator.group;

/**
 * 七牛
 *
 * @author Mark sunlightcs@gmail.com
 */
public interface QiniuGroup {
}
